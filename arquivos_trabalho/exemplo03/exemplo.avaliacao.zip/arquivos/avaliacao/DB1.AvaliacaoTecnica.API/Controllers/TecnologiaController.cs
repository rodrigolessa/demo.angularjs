﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using DB1.AvaliacaoTecnica.Domain;
using DB1.AvaliacaoTecnica.Domain.Entities;
using DB1.AvaliacaoTecnica.Domain.Repositories;
using DB1.AvaliacaoTecnica.Infrastructure;
using DB1.AvaliacaoTecnica.Infrastructure.Data;
using DB1.AvaliacaoTecnica.Infrastructure.Data.Repositories;

namespace DB1.AvaliacaoTecnica.API.Controllers
{
    public class TecnologiaController : ApiController
    {
        private IQueryableUnitOfWork _unit;
        private ITecnologiaRepository _repository;

        public TecnologiaController()
        {
            _unit = new MainUnitOfWork();
            _repository = new TecnologiaRepository(_unit);
        }

        // GET: api/Tecnologia
        public IEnumerable<Tecnologia> Get()
        {
            return _repository.GetAll();
        }

        // GET: api/Tecnologia/5
        public Tecnologia Get(int id)
        {
            return _repository.Get(id);
        }

        // POST: api/Tecnologia
        public BusinessResponse<Boolean> Post(Tecnologia item)
        {
            _repository.Add(item);
            _unit.Commit();

            return new BusinessResponse<bool>(true, "Salvo com sucesso!");
        }

        // PUT: api/Tecnologia/5
        public BusinessResponse<Boolean> Put(Tecnologia item)
        {
            var tecnologia = _repository.Get(item.Id);
            if (tecnologia == null)
                return new BusinessResponse<bool>(true, "Não encontrado.");

            _repository.Merge(tecnologia, item);
            _repository.Modify(tecnologia);
            _unit.Commit();

            return new BusinessResponse<bool>(true, "Salvo com sucesso!");
        }

        // DELETE: api/Tecnologia/5
        public BusinessResponse<Boolean> Delete(int id)
        {
            var tecnologia = _repository.Get(id);
            if (tecnologia == null)
                return new BusinessResponse<bool>(true, "Não encontrado.");

            _repository.Remove(tecnologia);
            _unit.Commit();

            return new BusinessResponse<bool>(true, "Excluido com sucesso!");
        }
    }
}
