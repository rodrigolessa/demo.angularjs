﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using DB1.AvaliacaoTecnica.Domain;
using DB1.AvaliacaoTecnica.Domain.Entities;
using DB1.AvaliacaoTecnica.Domain.Repositories;
using DB1.AvaliacaoTecnica.Infrastructure;
using DB1.AvaliacaoTecnica.Infrastructure.Data;
using DB1.AvaliacaoTecnica.Infrastructure.Data.Repositories;

namespace DB1.AvaliacaoTecnica.API.Controllers
{
    public class VagaController : ApiController
    {
        private IQueryableUnitOfWork _unit;
        private IVagaRepository _repository;

        public VagaController()
        {
            _unit = new MainUnitOfWork();
            _repository = new VagaRepository(_unit);
        }

        // GET: api/Vaga
        public IEnumerable<Vaga> Get()
        {
            return _repository.GetAll();
        }

        // GET: api/Vaga/5
        public Vaga Get(int id)
        {
            return _repository.Get(id);
        }

        // POST: api/Vaga
        public BusinessResponse<Boolean> Post(Vaga item)
        {
            _repository.Add(item);
            _unit.Commit();

            return new BusinessResponse<bool>(true, "Salvo com sucesso!");
        }

        // PUT: api/Vaga/5
        public BusinessResponse<Boolean> Put(Vaga item)
        {
            var vaga = _repository.Get(item.Id);
            if (vaga == null)
                return new BusinessResponse<bool>(true, "Não encontrado.");

            _repository.Merge(vaga, item);
            _repository.Modify(vaga);
            _unit.Commit();

            return new BusinessResponse<bool>(true, "Salvo com sucesso!");
        }

        // DELETE: api/Vaga/5
        public BusinessResponse<Boolean> Delete(int id)
        {
            var vaga = _repository.Get(id);
            if (vaga == null)
                return new BusinessResponse<bool>(true, "Não encontrado.");

            _repository.Remove(vaga);
            _unit.Commit();

            return new BusinessResponse<bool>(true, "Excluido com sucesso!");
        }
    }
}
