﻿angular.module('db1.avaliacao.tecnica',
[
    'ngRoute'
]);

//angular.bootstrap(document, ['db1.avaliacao.tecnica']);