﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DB1.AvaliacaoTecnica.Domain;
using DB1.AvaliacaoTecnica.Domain.Entities;
using DB1.AvaliacaoTecnica.Domain.Repositories;

namespace DB1.AvaliacaoTecnica.Infrastructure.Data.Repositories
{
    public class VagaRepository : Repository<Vaga>, IVagaRepository
    {
        public VagaRepository(IQueryableUnitOfWork unitOfWork)
            : base(unitOfWork)
        {
        }
    }
}
