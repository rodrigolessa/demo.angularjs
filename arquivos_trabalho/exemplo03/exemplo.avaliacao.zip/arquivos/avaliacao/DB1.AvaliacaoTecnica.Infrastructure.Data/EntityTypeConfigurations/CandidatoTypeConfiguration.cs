﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using System.Data.Entity.Infrastructure.Annotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DB1.AvaliacaoTecnica.Domain.Entities;
using DB1.AvaliacaoTecnica.Domain.Entities.ValueObjects;

namespace DB1.AvaliacaoTecnica.Infrastructure.Data.EntityTypeConfigurations
{
    public class CandidatoTypeConfiguration : EntityTypeConfiguration<Candidato>
    {
        public CandidatoTypeConfiguration()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Nome)
                .IsRequired()
                .HasMaxLength(100);

            Property(x => x.Email.Endereco)
                .HasColumnName("Email")
                .HasMaxLength(Email.EnderecoMaxLength);
                //.HasColumnAnnotation(IndexAnnotation.AnnotationName, new IndexAnnotation(new IndexAttribute("IX_Email", 3) { IsUnique = true }));

            // Table & Column Mappings
            this.ToTable("Candidato");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.Nome).HasColumnName("Nome");
            this.Property(t => t.DataDeInclusao).HasColumnName("DataDeInclusao");

            // Relationships
            this.HasMany(t => t.Tecnologias)
                .WithMany(t => t.Candidatos)
                .Map(m =>
                {
                    m.ToTable("CandidatoTecnologia");
                    m.MapLeftKey("IdCandidato");
                    m.MapRightKey("IdTecnologia");
                });

            this.HasMany(t => t.Vagas)
                .WithMany(t => t.Candidatos)
                .Map(m =>
                {
                    m.ToTable("CandidatoVaga");
                    m.MapLeftKey("IdCandidato");
                    m.MapRightKey("IdVaga");
                });

        }
    }
}
