﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using System.Data.Entity.Infrastructure.Annotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DB1.AvaliacaoTecnica.Domain.Entities;

namespace DB1.AvaliacaoTecnica.Infrastructure.Data.EntityTypeConfigurations
{
    public class TecnologiaDaVagaTypeConfiguration : EntityTypeConfiguration<TecnologiaDaVaga>
    {
        public TecnologiaDaVagaTypeConfiguration()
        {
            // Primary Key
            this.HasKey(t => new { t.IdTecnologia, t.IdVaga });

            // Properties
            this.Property(t => t.IdVaga)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.IdTecnologia)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            // Table & Column Mappings
            this.ToTable("TecnologiaDaVaga");
            this.Property(t => t.IdVaga).HasColumnName("IdUser");
            this.Property(t => t.IdTecnologia).HasColumnName("IdRoles");
            this.Property(t => t.Peso).HasColumnName("Peso");

            // Relationships
            this.HasRequired(t => t.Tecnologia)
                .WithMany(t => t.TecnologiasDaVaga)
                .HasForeignKey(d => d.IdTecnologia);
            this.HasRequired(t => t.Vaga)
                .WithMany(t => t.TecnologiasDaVaga)
                .HasForeignKey(d => d.IdVaga);
        }
    }
}
