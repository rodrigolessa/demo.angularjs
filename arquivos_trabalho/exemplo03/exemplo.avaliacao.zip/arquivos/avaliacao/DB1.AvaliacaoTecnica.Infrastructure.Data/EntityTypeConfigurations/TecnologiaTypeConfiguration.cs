﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using System.Data.Entity.Infrastructure.Annotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DB1.AvaliacaoTecnica.Domain.Entities;

namespace DB1.AvaliacaoTecnica.Infrastructure.Data.EntityTypeConfigurations
{
    public class TecnologiaTypeConfiguration : EntityTypeConfiguration<Tecnologia>
    {
        public TecnologiaTypeConfiguration()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Nome)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("Tecnologia");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.Nome).HasColumnName("Nome");
            this.Property(t => t.DataDeInclusao).HasColumnName("DataDeInclusao");
        }
    }
}
