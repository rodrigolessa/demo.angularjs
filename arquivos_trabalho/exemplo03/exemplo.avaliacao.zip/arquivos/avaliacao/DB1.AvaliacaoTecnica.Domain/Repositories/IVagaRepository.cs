﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DB1.AvaliacaoTecnica.Domain.Entities;

namespace DB1.AvaliacaoTecnica.Domain.Repositories
{
    public interface IVagaRepository : IRepository<Vaga>
    {
    }
}
