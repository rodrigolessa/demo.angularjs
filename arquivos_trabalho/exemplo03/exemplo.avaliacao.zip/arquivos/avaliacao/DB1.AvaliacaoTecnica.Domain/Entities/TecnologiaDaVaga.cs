﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB1.AvaliacaoTecnica.Domain.Entities
{
    public partial class TecnologiaDaVaga
    {
        public int IdVaga { get; set; }
        public int IdTecnologia { get; set; }
        public Nullable<int> Peso { get; set; }
        public virtual Tecnologia Tecnologia { get; set; }
        public virtual Vaga Vaga { get; set; }
    }
}
