﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB1.AvaliacaoTecnica.Domain.Entities
{
    public partial class Vaga : EntityBase
    {
        public Vaga()
        {
            this.TecnologiasDaVaga = new List<TecnologiaDaVaga>();
            this.Candidatos = new List<Candidato>();
        }

        public string Titulo { get; set; }
        public string Descricao { get; set; }
        public virtual ICollection<TecnologiaDaVaga> TecnologiasDaVaga { get; set; }
        public virtual ICollection<Candidato> Candidatos { get; set; }
    }
}
