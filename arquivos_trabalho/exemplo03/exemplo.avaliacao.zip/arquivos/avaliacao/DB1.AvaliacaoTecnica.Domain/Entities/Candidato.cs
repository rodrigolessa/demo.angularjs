﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DB1.AvaliacaoTecnica.Domain.Entities.ValueObjects;

namespace DB1.AvaliacaoTecnica.Domain.Entities
{
    public class Candidato : EntityBase
    {
        #region Construtor

        protected Candidato()
        {
            this.Tecnologias = new List<Tecnologia>();
            this.Vagas = new List<Vaga>();
        }

        public Candidato(string nome, Email email)
        {
            this.Tecnologias = new List<Tecnologia>();
            this.Vagas = new List<Vaga>();

            SetEmail(email);
            DataDeInclusao = DateTime.Now;
        }

        #endregion

        public string Nome { get; private set; }
        public Email Email { get; private set; }
        public virtual ICollection<Tecnologia> Tecnologias { get; set; }
        public virtual ICollection<Vaga> Vagas { get; set; }

        public void SetEmail(Email email)
        {
            if (email == null)
                throw new Exception("E-mail é obrigatório.");
            Email = email;
        }
    }
}
