﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB1.AvaliacaoTecnica.Domain.Entities
{
    public class Tecnologia : EntityBase
    {
        public Tecnologia()
        {
            this.TecnologiasDaVaga = new List<TecnologiaDaVaga>();
            this.Candidatos = new List<Candidato>();
        }

        public string Nome { get; set; }
        public virtual ICollection<TecnologiaDaVaga> TecnologiasDaVaga { get; set; }
        public virtual ICollection<Candidato> Candidatos { get; set; }
    }
}
