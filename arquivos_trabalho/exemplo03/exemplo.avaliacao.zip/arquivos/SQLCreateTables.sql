USE [DB1AvaliacaoTecnica]
GO

/* ROLLBACK
DROP TABLE [dbo].[CandidatoTecnologia]
GO

DROP TABLE [dbo].[CandidatoVaga]
GO

DROP TABLE [dbo].[TecnologiaDaVaga]
GO

DROP TABLE [dbo].[Candidato]
GO
 
DROP TABLE [dbo].[Vaga]
GO
 
DROP TABLE [dbo].[Tecnologia]
GO
*/

CREATE TABLE [dbo].[Candidato](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Nome] [varchar](100) NOT NULL,
	[Email] [varchar](100) NOT NULL,
	[DataDeInclusao] [DateTime] NULL,
	PRIMARY KEY CLUSTERED
	(
		[Id] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
 
CREATE TABLE [dbo].[Vaga](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Titulo] [varchar](100) NOT NULL,
	[Descricao] [varchar](100) NOT NULL,
	[DataDeInclusao] [DateTime] NULL,
	PRIMARY KEY CLUSTERED
	(
		[Id] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
 
CREATE TABLE [dbo].[Tecnologia](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Nome] [varchar](100) NOT NULL,
	[DataDeInclusao] [DateTime] NULL,
	PRIMARY KEY CLUSTERED
	(
		[Id] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
 
CREATE TABLE [dbo].[TecnologiaDaVaga](
	[IdVaga] [int] NOT NULL,
	[IdTecnologia] [int] NOT NULL,
	[Peso] [int] NULL,
	PRIMARY KEY CLUSTERED
	(
		[IdVaga] ASC,
		[IdTecnologia] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


CREATE TABLE [dbo].[CandidatoVaga](
	[IdVaga] [int] NOT NULL,
	[IdCandidato] [int] NOT NULL,
	PRIMARY KEY CLUSTERED
	(
		[IdVaga] ASC,
		[IdCandidato] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[CandidatoTecnologia](
	[IdTecnologia] [int] NOT NULL,
	[IdCandidato] [int] NOT NULL,
	PRIMARY KEY CLUSTERED
	(
		[IdTecnologia] ASC,
		[IdCandidato] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

-------------------------------------------------------
-- CHAVES TecnologiaDaVaga
 
ALTER TABLE [dbo].[TecnologiaDaVaga]  WITH CHECK ADD  CONSTRAINT [fk_TecnologiaDaVaga_Tecnologia] FOREIGN KEY([IdTecnologia])
REFERENCES [dbo].[Tecnologia] ([Id])
GO
 
ALTER TABLE [dbo].[TecnologiaDaVaga] CHECK CONSTRAINT [fk_TecnologiaDaVaga_Tecnologia]
GO
 
ALTER TABLE [dbo].[TecnologiaDaVaga]  WITH CHECK ADD  CONSTRAINT [fk_TecnologiaDaVaga_Vaga] FOREIGN KEY([IdVaga])
REFERENCES [dbo].[Vaga] ([Id])
GO
 
ALTER TABLE [dbo].[TecnologiaDaVaga] CHECK CONSTRAINT [fk_TecnologiaDaVaga_Vaga]
GO

-------------------------------------------------------
-- CHAVES CandidatoVaga

ALTER TABLE [dbo].[CandidatoVaga]  WITH CHECK ADD  CONSTRAINT [fk_CandidatoVaga_Candidato] FOREIGN KEY([IdCandidato])
REFERENCES [dbo].[Candidato] ([Id])
GO
 
ALTER TABLE [dbo].[CandidatoVaga] CHECK CONSTRAINT [fk_CandidatoVaga_Candidato]
GO
 
ALTER TABLE [dbo].[CandidatoVaga]  WITH CHECK ADD  CONSTRAINT [fk_CandidatoVaga_Vaga] FOREIGN KEY([IdVaga])
REFERENCES [dbo].[Vaga] ([Id])
GO
 
ALTER TABLE [dbo].[CandidatoVaga] CHECK CONSTRAINT [fk_CandidatoVaga_Vaga]
GO

-------------------------------------------------------
-- CHAVES CandidatoTecnologia

ALTER TABLE [dbo].[CandidatoTecnologia]  WITH CHECK ADD  CONSTRAINT [fk_CandidatoTecnologia_Candidato] FOREIGN KEY([IdCandidato])
REFERENCES [dbo].[Candidato] ([Id])
GO
 
ALTER TABLE [dbo].[CandidatoTecnologia] CHECK CONSTRAINT [fk_CandidatoTecnologia_Candidato]
GO
 
ALTER TABLE [dbo].[CandidatoTecnologia]  WITH CHECK ADD  CONSTRAINT [fk_CandidatoTecnologia_Tecnologia] FOREIGN KEY([IdTecnologia])
REFERENCES [dbo].[Tecnologia] ([Id])
GO
 
ALTER TABLE [dbo].[CandidatoTecnologia] CHECK CONSTRAINT [fk_CandidatoTecnologia_Tecnologia]
GO
