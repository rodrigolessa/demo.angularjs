using System;
using System.Collections.Generic;

namespace reverse.code.tecnica.domain.Models
{
    public partial class Candidato
    {
        public Candidato()
        {
            this.Tecnologias = new List<Tecnologia>();
            this.Vagas = new List<Vaga>();
        }

        public int Id { get; set; }
        public string Nome { get; set; }
        public string Email { get; set; }
        public Nullable<System.DateTime> DataDeInclusao { get; set; }
        public virtual ICollection<Tecnologia> Tecnologias { get; set; }
        public virtual ICollection<Vaga> Vagas { get; set; }
    }
}
