using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace reverse.code.tecnica.domain.Models.Mapping
{
    public class VagaMap : EntityTypeConfiguration<Vaga>
    {
        public VagaMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Titulo)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.Descricao)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("Vaga");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.Titulo).HasColumnName("Titulo");
            this.Property(t => t.Descricao).HasColumnName("Descricao");
            this.Property(t => t.DataDeInclusao).HasColumnName("DataDeInclusao");
        }
    }
}
