using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace reverse.code.tecnica.domain.Models.Mapping
{
    public class TecnologiaMap : EntityTypeConfiguration<Tecnologia>
    {
        public TecnologiaMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Nome)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("Tecnologia");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.Nome).HasColumnName("Nome");
            this.Property(t => t.DataDeInclusao).HasColumnName("DataDeInclusao");
        }
    }
}
