using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace reverse.code.tecnica.domain.Models.Mapping
{
    public class CandidatoMap : EntityTypeConfiguration<Candidato>
    {
        public CandidatoMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Nome)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.Email)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("Candidato");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.Nome).HasColumnName("Nome");
            this.Property(t => t.Email).HasColumnName("Email");
            this.Property(t => t.DataDeInclusao).HasColumnName("DataDeInclusao");

            // Relationships
            this.HasMany(t => t.Tecnologias)
                .WithMany(t => t.Candidatoes)
                .Map(m =>
                    {
                        m.ToTable("CandidatoTecnologia");
                        m.MapLeftKey("IdCandidato");
                        m.MapRightKey("IdTecnologia");
                    });

            this.HasMany(t => t.Vagas)
                .WithMany(t => t.Candidatoes)
                .Map(m =>
                    {
                        m.ToTable("CandidatoVaga");
                        m.MapLeftKey("IdCandidato");
                        m.MapRightKey("IdVaga");
                    });


        }
    }
}
