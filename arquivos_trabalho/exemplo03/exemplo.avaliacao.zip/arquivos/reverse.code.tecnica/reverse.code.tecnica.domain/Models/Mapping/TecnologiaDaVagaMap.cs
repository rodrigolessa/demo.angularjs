using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace reverse.code.tecnica.domain.Models.Mapping
{
    public class TecnologiaDaVagaMap : EntityTypeConfiguration<TecnologiaDaVaga>
    {
        public TecnologiaDaVagaMap()
        {
            // Primary Key
            this.HasKey(t => new { t.IdVaga, t.IdTecnologia });

            // Properties
            this.Property(t => t.IdVaga)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.IdTecnologia)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            // Table & Column Mappings
            this.ToTable("TecnologiaDaVaga");
            this.Property(t => t.IdVaga).HasColumnName("IdVaga");
            this.Property(t => t.IdTecnologia).HasColumnName("IdTecnologia");
            this.Property(t => t.Peso).HasColumnName("Peso");

            // Relationships
            this.HasRequired(t => t.Tecnologia)
                .WithMany(t => t.TecnologiaDaVagas)
                .HasForeignKey(d => d.IdTecnologia);
            this.HasRequired(t => t.Vaga)
                .WithMany(t => t.TecnologiaDaVagas)
                .HasForeignKey(d => d.IdVaga);

        }
    }
}
