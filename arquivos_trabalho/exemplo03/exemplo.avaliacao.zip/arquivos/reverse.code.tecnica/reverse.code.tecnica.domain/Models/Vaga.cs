using System;
using System.Collections.Generic;

namespace reverse.code.tecnica.domain.Models
{
    public partial class Vaga
    {
        public Vaga()
        {
            this.TecnologiaDaVagas = new List<TecnologiaDaVaga>();
            this.Candidatoes = new List<Candidato>();
        }

        public int Id { get; set; }
        public string Titulo { get; set; }
        public string Descricao { get; set; }
        public Nullable<System.DateTime> DataDeInclusao { get; set; }
        public virtual ICollection<TecnologiaDaVaga> TecnologiaDaVagas { get; set; }
        public virtual ICollection<Candidato> Candidatoes { get; set; }
    }
}
