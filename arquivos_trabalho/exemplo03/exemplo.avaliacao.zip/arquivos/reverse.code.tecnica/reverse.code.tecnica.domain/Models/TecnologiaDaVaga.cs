using System;
using System.Collections.Generic;

namespace reverse.code.tecnica.domain.Models
{
    public partial class TecnologiaDaVaga
    {
        public int IdVaga { get; set; }
        public int IdTecnologia { get; set; }
        public Nullable<int> Peso { get; set; }
        public virtual Tecnologia Tecnologia { get; set; }
        public virtual Vaga Vaga { get; set; }
    }
}
