using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using reverse.code.tecnica.domain.Models.Mapping;

namespace reverse.code.tecnica.domain.Models
{
    public partial class DB1AvaliacaoTecnicaContext : DbContext
    {
        static DB1AvaliacaoTecnicaContext()
        {
            Database.SetInitializer<DB1AvaliacaoTecnicaContext>(null);
        }

        public DB1AvaliacaoTecnicaContext()
            : base("Name=DB1AvaliacaoTecnicaContext")
        {
        }

        public DbSet<Candidato> Candidatoes { get; set; }
        public DbSet<Tecnologia> Tecnologias { get; set; }
        public DbSet<TecnologiaDaVaga> TecnologiaDaVagas { get; set; }
        public DbSet<Vaga> Vagas { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add(new CandidatoMap());
            modelBuilder.Configurations.Add(new TecnologiaMap());
            modelBuilder.Configurations.Add(new TecnologiaDaVagaMap());
            modelBuilder.Configurations.Add(new VagaMap());
        }
    }
}
