# avaliacao.angularjs
Avaliação C# + Web API + AngularJS

Tecnologias e ferramentas utilizadas:
* Jquery - https://jquery.com/
* AngularJS - https://angularjs.org/
* Angular-Route
* Bootstrap - http://getbootstrap.com/
* Visual Studio Community 2015
* SQL Server 2012
* Entity framework 6
* NUnit

Histórico de tarefas do projeto:
https://trello.com/b/yHYkvJt4/avaliacao-angularjs#

Instalação do projeto:
-Crie uma nova Database com o nome "DB1AvaliacaoTecnica"
-Altere login e senha da string de conexao dos projetos API e Teste de Integração: